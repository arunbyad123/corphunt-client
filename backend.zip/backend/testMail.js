import transporter from "./config/nodemailer.js";

async function sendTestMail() {
  try {
    const info = await transporter.sendMail({
      from: `"CorpHunt" <${process.env.EMAIL_USER}>`,
      to: "yourpersonalemail@gmail.com", // put your email to test
      subject: "Test Email",
      text: "This is a test email from Nodemailer + Gmail App Password setup.",
    });

    console.log("✅ Email sent successfully:", info.messageId);
  } catch (error) {
    console.error("❌ Error sending email:", error);
  }
}

sendTestMail();
