// server.js
import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors";
import nodemailer from "nodemailer";

import authRoutes from "./routes/authRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

// Debugging: Check if email creds are loaded
console.log("EMAIL_USER:", process.env.EMAIL_USER);
console.log("EMAIL_PASS:", process.env.EMAIL_PASS ? "Loaded" : "Missing");

// ✅ Setup Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER, // Gmail (App Password required)
    pass: process.env.EMAIL_PASS,
  },
});

// ✅ Signup Route with Email
app.post("/api/signup", async (req, res) => {
  const { email } = req.body;

  try {
    const info = await transporter.sendMail({
      from: `"CorpHunt" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Welcome to CorpHunt",
      text: "Thanks for signing up with us!",
      html: "<h1>Welcome to CorpHunt 🎉</h1><p>Thanks for joining us!</p>",
    });

    res.json({
      success: true,
      message: "Signup successful & email sent!",
      messageId: info.messageId,
    });
  } catch (err) {
    console.error("Signup email error:", err);
    res.status(500).json({ success: false, error: "Signup succeeded but email failed" });
  }
});

// ✅ Your existing routes
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);

// Root route
app.get("/", (req, res) => {
  res.send("API is running...");
});

// ✅ MongoDB connection (no deprecated options anymore 🚀)
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
